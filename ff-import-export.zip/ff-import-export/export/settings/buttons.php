<?php
if( !$selected_post_type ) return;
?>

<p><span class="button button-primary" id="export_preview_btn">Preview</span> <input type="number" value=1 name="preview_num" class="w_80"></p>

<p><span class="button button-primary" id="export_start">Export</span>