<?php
pre_debug('upload file');

// class Upload_File {
    
    

// }

// $test = new Upload_File();

// $url = 'http://localhost/wp1/wp-content/uploads/2024/03/test-zip.zip';
// $test->upload_file($url);


// $attachment_id = get_attachment_id_by_filename();
// $attachment_id = $test->upload_file_from_url($url);
// $test->upload_file_from_url( $file_url );
